const $ = (s) => document.querySelector(s);
const tools = {
  caption: {title:"Caption ideas", make:(topic,platform,tone)=>[
    `${topic} — here's what you need to know. Save this for later.`,
    `A simple reminder about ${topic}: small steps can make a real difference. What do you think?`,
    `Let's talk about ${topic}. Which part would you add to this list?`,
    `If ${topic} is on your mind, start here. Share this with someone who needs it.`
  ].join("\n\n")},
  hashtags: {title:"Hashtag helper", make:(topic,platform,tone)=>{
    const words=topic.toLowerCase().replace(/[^a-z0-9 ]/g," ").split(/\s+/).filter(w=>w.length>2);
    const base=[...new Set(words)].slice(0,5).map(w=>"#"+w);
    const extras=["#contentcreator","#creatortips","#learnsomething","#socialmedia","#dailyinspiration"];
    return [...base,...extras].join(" ")+"\n\nTip: remove any tag that doesn't accurately describe your post.";
  }},
  script: {title:"Short video script", make:(topic,platform,tone)=>`HOOK (first 2 seconds)\n"Want a simpler way to understand ${topic}?"\n\nMAIN POINT 1\nIntroduce the problem your viewer cares about.\n\nMAIN POINT 2\nShare one practical example or useful step about ${topic}.\n\nMAIN POINT 3\nGive one quick takeaway viewers can try today.\n\nCLOSE\n"Follow for more practical tips — and tell me what you'd like explained next."\n\nCreator note: replace the placeholders with your own experience and verified details.`},
  bio: {title:"Profile bio ideas", make:(topic,platform,tone)=>`1. Sharing simple ideas about ${topic} ✨\nUseful tips • Fresh ideas • New posts\n\n2. Your daily place for ${topic}\nLearn something. Try something. Grow.\n\n3. Making ${topic} easier to understand.\nFollow for practical content and helpful ideas.`},
  thumbnail: {title:"Thumbnail concepts", make:(topic,platform,tone)=>`CONCEPT 1 — The clear promise\nText: "${topic.toUpperCase()}"\nVisual: One expressive subject, clean background, 3–5 words maximum.\n\nCONCEPT 2 — The curiosity gap\nText: "STOP DOING THIS"\nVisual: Before/after layout that genuinely reflects the video.\n\nCONCEPT 3 — The numbered guide\nText: "3 THINGS TO KNOW"\nVisual: Large number, one relevant object, high contrast.\n\nKeep the thumbnail accurate to the actual video. Avoid misleading claims.`}
};
let current="caption";
function selectTool(name){
  current=name;
  document.querySelectorAll(".tool-card").forEach(b=>b.classList.toggle("active",b.dataset.tool===name));
  $("#tool-title").textContent=tools[name].title;
  $("#output").innerHTML='<div class="output-placeholder"><span>✦</span><b>Your ideas will appear here</b><small>Enter a topic and select “Create ideas”.</small></div>';
}
document.querySelectorAll(".tool-card").forEach(b=>b.addEventListener("click",()=>selectTool(b.dataset.tool)));
$("#generator-form").addEventListener("submit",e=>{
  e.preventDefault();
  const topic=$("#topic").value.trim();
  if(!topic)return;
  const result=tools[current].make(topic,$("#platform").value,$("#tone").value);
  const output=$("#output");
  output.textContent=result;
  const actions=document.createElement("div"); actions.className="output-actions";
  const copy=document.createElement("button"); copy.className="copy-btn"; copy.textContent="Copy result";
  copy.addEventListener("click",async()=>{try{await navigator.clipboard.writeText(result);copy.textContent="Copied ✓";}catch{copy.textContent="Select and copy text";}});
  actions.append(copy); output.append(actions);
});
$("#year").textContent=new Date().getFullYear();
if(typeof SMARTLINK_URL!=="undefined" && /^https:\/\/\S+$/i.test(SMARTLINK_URL)){
  const link=$("#smartlink-cta"); link.href=SMARTLINK_URL; link.hidden=false; $("#smartlink-status").hidden=true;
}

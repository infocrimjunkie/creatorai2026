// Approved Adsterra Smartlink supplied by the site owner.
const SMARTLINK_URL = "https://auctionr.org/4/7b70868cae6215093c1d01f1932fc2e5";

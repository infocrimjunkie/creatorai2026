# CreatorAI — free static website

A mobile-friendly static website with five browser-based creator tools:
1. Caption ideas
2. Hashtag helper
3. Short video script
4. Profile bio
5. Thumbnail concepts

## Before publishing
- Replace `infocrimjunkie` in `index.html`, `robots.txt`, and `sitemap.xml` with your GitHub username.
- Replace the placeholder email in `contact.html` with an address you control.
- The supplied Adsterra Smartlink is already configured in `config.js`.
- Review the privacy and terms pages. Update them if you add analytics, cookies, ad scripts, forms, or other third-party services.
- The generators are rule-based browser tools, not a connected generative-AI service. Do not describe them as AI-powered unless you later connect a real AI API.

## Publish with GitHub Pages
1. Sign in to GitHub and create a **public** repository named exactly `infocrimjunkie.github.io`.
2. Upload all files in this folder to the repository root (not inside another nested folder).
3. Open repository **Settings → Pages**.
4. Under Build and deployment, select **Deploy from a branch**, branch `main`, folder `/ (root)`, then Save.
5. Wait for the Pages deployment to finish. Your site will be at `https://infocrimjunkie.github.io/`.

## Smartlink placement
The homepage contains a clearly labelled, optional sponsored-offer area. The button remains hidden until a valid HTTPS Smartlink is configured in `config.js`. Do not force visitors to click, auto-redirect them, incentivize clicks, or disguise the destination. Follow the current Adsterra publisher terms for your account and traffic source.

## SEO and traffic quality
- Publish original, useful guides and examples over time.
- Share relevant pages with audiences that genuinely want the content.
- Do not buy traffic, use bots, VPN traffic, click exchanges, or ask visitors to click ads.
- A country list is not a revenue guarantee. Monitor actual country, device, format and earnings data in the Adsterra dashboard.
